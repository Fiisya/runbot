/**
lilychanj x Plugins Base
**/
require('./settings')
const { makeWASocket, makeCacheableSignalKeyStore, downloadContentFromMessage, emitGroupParticipantsUpdate, emitGroupUpdate, generateWAMessageContent, generateWAMessage, makeInMemoryStore, prepareWAMessageMedia, generateWAMessageFromContent, MediaType, areJidsSameUser, WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, GroupMetadata, initInMemoryKeyStore, getContentType, MiscMessageGenerationOptions, useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, WAFlag, WANode, WAMetric, ChatModification, MessageTypeProto, WALocationMessage, ReconnectMode, WAContextInfo, proto, WAGroupMetadata, ProxyAgent, waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, WAContactsArrayMessage, WAGroupInviteMessage, WATextMessage, WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, MediaConnInfo, URL_REGEX, WAUrlInfo, WA_DEFAULT_EPHEMERAL, WAMediaUpload, mentionedJid, processTime, Browser, MessageType, Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, GroupSettingChange, DisconnectReason, WASocket, getStream, WAProto, isBaileys, PHONENUMBER_MCC, AnyMessageContent, useMultiFileAuthState, fetchLatestBaileysVersion, templateMessage, InteractiveMessage, Header } = require('@adiwajshing/baileys')
const { exec, spawn, execSync } = require("child_process")
const fs = require('fs')
const fsx = require('fs-extra')
const util = require('util')
const fetch = require('node-fetch')
const path = require('path')
const axios = require('axios')
const chalk = require('chalk')
const FormData = require('form-data');
const cheerio = require('cheerio')
const { randomBytes } = require('crypto')
const { performance } = require("perf_hooks");
const process = require('process');
const moment = require("moment-timezone")
const PhoneNum = require("awesome-phonenumber")
const os = require('os');
const checkDiskSpace = require('check-disk-space').default;
const speed = require('performance-now')
const ms = toMs = require('ms')
const gis = require('g-i-s')
const yts = require("yt-search")
const didyoumean = require('didyoumean');
const similarity = require('similarity')
const more = String.fromCharCode(8206);
const readmore = more.repeat(4001);
const timestampp = speed();
const latensi = speed() - timestampp
const { deobfuscate } = require('obfuscator-io-deobfuscator');
const { bytesToSize, checkBandwidth, formatSize, jsonformat, nganuin, shorturl, color } = require("./lib/function");
const {
    toAudio,
    toPTT,
    toVideo,
    addExifAvatar
} = require('./lib/converter')
const {
	pomfCDN,
    TelegraPh,
    UploadFileUgu,
    webp2mp4File,
    catbox,
    floNime,
    webp2mp4
} = require('./lib/uploader')
const ntilink = JSON.parse(fs.readFileSync("./lib/antilink.json"))
const { addExif } = require('./lib/exif')
const {
    smsg,
    formatDate,
    getTime,
    getGroupAdmins,
    formatp,
    await,
    sleep,
    runtime,   
    clockString,
    msToDate,
    sort,
    toNumber,
    enumGetKey,
    fetchJson,
    getBuffer,
    json,
    delay,
    format,
    logic,
    generateProfilePicture,
    parseMention,
    getRandom,
    fetchBuffer,
    buffergif,
    GIFBufferToVideoBuffer,
    totalcase,
    isUrl
} = require('./lib/myfunc')
const { android1 } = require('./lib/android1')
const { youtube } = require("btch-downloader")

module.exports = alfixd = async (alfixd, m, chatUpdate, store) => {
try {
const body = (m && m.mtype) ? (
m.mtype === 'conversation' ? m.message?.conversation :
m.mtype === 'imageMessage' ? m.message?.imageMessage?.caption :
m.mtype === 'videoMessage' ? m.message?.videoMessage?.caption :
m.mtype === 'extendedTextMessage' ? m.message?.extendedTextMessage?.text :
m.mtype === 'buttonsResponseMessage' ? m.message?.buttonsResponseMessage?.selectedButtonId :
m.mtype === 'listResponseMessage' ? m.message?.listResponseMessage?.singleSelectReply?.selectedRowId :
m.mtype === 'templateButtom.replyMessage' ? m.message?.templateButtom.replyMessage?.selectedId :
m.mtype === 'messageContextInfo' ? (
m.message?.buttonsResponseMessage?.selectedButtonId || 
m.message?.listResponseMessage?.singleSelectReply?.selectedRowId || 
m.text
) : ''
) : '';
const budy = (m && typeof m.text === 'string') ? m.text : '';
const prefix = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/.test(body) ? body.match(/^[°zZ#$@*+,.?=''():√%¢£¥€π¤ΠΦ_&><!`™©®Δ^βα~¦|/\\©^]/gi) : '.'
const isCmd = body.startsWith(prefix)
const from = m.key.remoteJid
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : ''
const args = body.trim().split(/ +/).slice(1);
const full_args = body.replace(command, '').slice(1).trim();
const pushname = m.pushName || "No Name";
const botNumber = await alfixd.decodeJid(alfixd.user.id);
const type = m
const sender = m.sender
const senderNumber = sender.split('@')[0]
const isCreator = (m && m.sender && [botNumber, ...global.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender)) || false;
const itsMe = (m && m.sender && m.sender == botNumber) || false;
const text = q = args.join(" ");
const fatkuns = m && (m.quoted || m);
const quoted = (fatkuns?.mtype == 'buttonsMessage') ? fatkuns[Object.keys(fatkuns)[1]] :
(fatkuns?.mtype == 'templateMessage') ? fatkuns.hydratedTemplate[Object.keys(fatkuns.hydratedTemplate)[1]] :
(fatkuns?.mtype == 'product') ? fatkuns[Object.keys(fatkuns)[0]] :
m.quoted || m;
const mime = ((quoted?.msg || quoted) || {}).mimetype || '';
const qmsg = (quoted?.msg || quoted);
const isMedia = /image|video|sticker|audio/.test(mime);
const isImage = (type === 'imageMessage')
const isVideo = (type === 'videoMessage')
const isSticker = (type == 'stickerMessage')
const isAudio = (type == 'audioMessage')
//group
const groupMetadata = m.isGroup ? await alfixd.groupMetadata(m.chat).catch(e => {}) : {};
const groupName = m.isGroup && groupMetadata ? groupMetadata.subject : '';
const participants = m.isGroup ? await groupMetadata.participants || [] : [];
const groupAdmins = m.isGroup ? await getGroupAdmins(participants) || [] : [];
const isBotAdmins = m.isGroup ? groupAdmins.includes(botNumber) : false;
const isBot = botNumber.includes(senderNumber)
const isAdmins = m.isGroup ? groupAdmins.includes(m.sender) : false;
const groupOwner = m.isGroup ? groupMetadata.owner || '' : '';
const isGroupOwner = m.isGroup ? (groupOwner ? groupOwner : groupAdmins).includes(m.sender) : false;
const froms = m.quoted ? m.quoted.sender : text ? (text.replace(/[^0-9]/g, '') ? text.replace(/[^0-9]/g, '') + '@s.whatsapp.net' : false) : false;
const isMediaalfixd = m.mtype
const AntiLink = m.isGroup ? ntilink.includes(from) : false 
const jangan = m.isGroup ? ntilink.includes(m.chat) : false	
const Styles = (text, style = 1) => {
var xStr = 'abcdefghijklmnopqrstuvwxyz1234567890'.split('');
  var yStr = {
1: 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ1234567890'
};
var replacer = [];
xStr.map((v, i) =>
replacer.push({
original: v,
convert: yStr[style].split('')[i]
})
);
var str = text.toLowerCase().split('');
var output = [];
str.map((v) => {
const find = replacer.find((x) => x.original == v);
find ? output.push(find.convert) : output.push(v);
});
return output.join('');
};

const Alfitext = (text, style = 1) => {
  var abc = 'abcdefghijklmnopqrstuvwxyz1234567890'.split('');
  var ehz = {
    1: 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀꜱᴛᴜᴠᴡxʏᴢ1234567890'
  };
  var replacer = [];
  abc.map((v, i) =>
    replacer.push({
      original: v,
      convert: ehz[style].split('')[i]
    })
  );
  var str = text.toLowerCase().split('');
  var output = [];
  str.map((v) => {
    const find = replacer.find((x) => x.original == v);
    find ? output.push(find.convert) : output.push(v);
  });
  return output.join('');
};

const pickRandom = (arr) => {
return arr[Math.floor(Math.random() * arr.length)]
}

    try {
        // Proses Auto Download berdasarkan URL
        if (budy.match('www.instagram.com/reel/')) {
            await alfixd.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });
            let anu = await fetchJson(`https://btch.us.kg/download/igdl?url=${budy}`);
            await alfixd.sendMessage(m.chat, { video: { url: anu.result[0].url }, caption: `` }, { quoted: m })
            await alfixd.sendMessage(m.chat, { react: { text: "☑️", key: m.key } });
        } else if (budy.match(/tiktok\.com/)) {
            await alfixd.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });
            let anu = await fetchJson(`https://api.vreden.my.id/api/tiktok?url=${budy}`)
let c = 0
for (let imgs of anu.result.data) {
if (imgs.type == "nowatermark") {
alfixd.sendMessage(m.chat, { video: { url: imgs.url }, caption: `*TikTok Download*\n\n- Title: ${anu.result.title}\n- Nickname: ${anu.result.author.nickname}\n- VT Like: ${anu.result.stats.likes}\n- Komentar: ${anu.result.stats.comment}\n- Share: ${anu.result.stats.share}\n- View: ${anu.result.stats.views}\n\n`}, {quoted: m})
}
if (imgs.type == "photo") {
if (c == 0) await alfixd.sendMessage(m.chat, { image: { url: imgs.url }, caption: `*TikTok Slide*\n\n${m.isGroup ? '_Sisa Foto Dikirim Di Private Chat_' : ""}` }, { quoted: m })
else await alfixd.sendMessage(m.sender, { image: { url: imgs.url }}, { quoted: m })
c += 1
await sleep(2000)
}
}
            await alfixd.sendMessage(m.chat, { react: { text: "☑️", key: m.key } });
        } else if (budy.match(/facebook\.com/)) {
            await alfixd.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });
            let anu = await fetchJson(`https://btch.us.kg/download/fbdl?url=${budy}`);
alfixd.sendMessage(m.chat, { video: { url: anu.result.Normal_video }, caption: 'Successfully downloaded video from that URL' }, { quoted: m });
            await alfixd.sendMessage(m.chat, { react: { text: "☑️", key: m.key } });
        } else if (budy.match(/youtube\.com|youtu\.be/)) {
            await alfixd.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });
             let proces = await (await fetch(`https://endpoint.web.id/downloader/yt-video?key=SRA-JWOMLN&url=${budy}&quality=360`)).json()
        let video4 = proces.result; 
        alfixd.sendMessage(m.chat,{video:{url: video4.downloadUrl }, caption: video4.title },{quoted: m})
            await alfixd.sendMessage(m.chat, { react: { text: "☑️", key: m.key } });
        }
    } catch (error) {
        await alfixd.sendMessage(m.chat, { react: { text: "✖️", key: m.key } });
        console.error("Error during Auto Download:", error);
    }

//================== [ TIME ] ==================//
const hariini = moment.tz('Asia/Jakarta').format('dddd, DD MMMM YYYY')
const wib = moment.tz('Asia/Jakarta').format('HH : mm : ss')
const wit = moment.tz('Asia/Jayapura').format('HH : mm : ss')
const wita = moment.tz('Asia/Makassar').format('HH : mm : ss')
let dt = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
const salam = 'Selamat '+dt.charAt(0).toUpperCase() + dt.slice(1)    
let dot = new Date(new Date + 3600000)
const dateIslamic = Intl.DateTimeFormat("id" + '-TN-u-ca-islamic', {day: 'numeric',month: 'long',year: 'numeric'}).format(dot)
const alfixddate = moment.tz('Asia/Jakarta').format('DD/MM/YYYY')
const time2 = moment().tz('Asia/Jakarta').format('HH:mm:ss')
        if(time2 < "23:59:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴍᴀʟᴀᴍ️🌕'
        }
        if(time2 < "19:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴘᴇᴛᴀɴɢ 🌤️'
        }
        if(time2 < "18:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ꜱᴏʀᴇ ⛅'
        }
        if(time2 < "15:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ꜱɪᴀɴɢ️☀️'
        }
        if(time2 < "10:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴘᴀɢɪ ⛅'
        }
        if(time2 < "05:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ꜱᴜʙᴜʜ 🌖'
        }
        if(time2 < "03:00:00"){
        var ucapanWaktu = 'ꜱᴇʟᴀᴍᴀᴛ ᴛᴇɴɢᴀʜ ᴍᴀʟᴀᴍ 🌘'
        }
//================== [ FUNCTION ] ==================//

async function formatUptime(uptime) {
  let seconds = Math.floor(uptime % 60);
  let minutes = Math.floor((uptime / 60) % 60);
  let hours = Math.floor((uptime / (60 * 60)) % 24);
  let days = Math.floor(uptime / (60 * 60 * 24));
  let formattedUptime = '';
  if (days > 0) formattedUptime += `${days} days `;
  if (hours > 0) formattedUptime += `${hours} hours `;
  if (minutes > 0) formattedUptime += `${minutes} minutes `;
  if (seconds > 0) formattedUptime += `${seconds} seconds`;
  return formattedUptime;
}


async function convertAngka(number) {
  return number.toLocaleString('en-US', {
    maximumFractionDigits: 2,
    notation: 'compact',
    compactDisplay: 'short'
  });
}  

if (prefix && command) {
let caseNames = getCaseNames();
function getCaseNames() {
const fs = require('fs');
try {
const data = fs.readFileSync('message.js', 'utf8');
const casePattern = /case\s+'([^']+)'/g;
const matches = data.match(casePattern);
if (matches) {
const caseNames = matches.map(match => match.replace(/case\s+'([^']+)'/, '$1'));
return caseNames;
} else {
return [];
} } catch (err) {
console.log('Terjadi kesalahan:', err);
return [];
}}
let noPrefix = command
let mean = didyoumean(noPrefix, caseNames);
let sim = similarity(noPrefix, mean);
let similarityPercentage = parseInt(sim * 100);
if (mean && noPrefix.toLowerCase() !== mean.toLowerCase()) {
let response = `Maaf, command yang kamu berikan salah. mungkin ini yang kamu maksud:\n\n•> ${prefix+mean}\n•> Kemiripan: ${similarityPercentage}%`
reply(response)
}}

const downloadMp3 = async (url) => {
let look = await yts(text);
let convert = look.videos[0];       
const pl = await youtube(convert.url)
await alfixd.sendMessage(m.chat,{
    audio: { url: pl.mp3  },
    fileName: convert.title + '.mp3',
    mimetype: 'audio/mpeg',
    contextInfo:{
        externalAdReply:{
            title:convert.title,
            body: botname,
            thumbnailUrl: convert.image,
            sourceUrl: pl.mp3,
            mediaType:1,
            mediaUrl:convert.url,
        }

    },
},{quoted:m})
}
//================== [ DATABASE ] ==================//
//================== [ CONSOL LOGG] ==================//

  if (m.message) {            
    console.log(chalk.cyan(`────────────『 ${chalk.redBright('ᴵᴺᶠᴼ ᴹᴱˢˢᴬᴳᴱ')} 』────────────`));
    console.log(`   ${chalk.cyan('» Message Type')}: ${m.mtype}`);
    console.log(`   ${chalk.cyan('» Sent Time')}: ${time2}`);
    console.log(`   ${chalk.cyan('» Sender Name')}: ${pushname || 'N/A'}`);
    console.log(`   ${chalk.cyan('» Chat ID')}: ${m.chat.split('@')[0]}`);
    console.log(`   ${chalk.cyan('» Chat Name')}: ${budy || 'N/A'}`);
    console.log(`   ${chalk.cyan('» Author By')}: LepiiNotDev`);
    console.log(chalk.cyan('───────────────────────────────────⳹\n'));
}
//================== [ FAKE REPLY ] ==================//
try {
pplu = await alfixd.profilePictureUrl(anu.id, 'image')
} catch {
pplu = 'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
}

const ments = (teks) => {return teks.match('@') ? [...teks.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net') : [sender]}

const fkontak = {
key: {
participants: "0@s.whatsapp.net",
remoteJid: "status@broadcast",
fromMe: false,
id: "Halo"},
message: {
contactMessage: {
vcard: `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
}},
participant: "0@s.whatsapp.net"
}

const qchanel = {
key: {
remoteJid: 'status@broadcast',
fromMe: false,
participant: '0@s.whatsapp.net'
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: `120363208710632243@newsletter`,
newsletterName: `${botname}`,
jpegThumbnail: "",
caption: `Powered By ${ownername}`,
inviteExpiration: Date.now() + 1814400000
}
}}

const fcall = { key: {fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast"} : {}) },'message': {extendedTextMessage: {text: body}}}
const Alfi = {
            key: {
                participant: `0@s.whatsapp.net`,
                ...(m.chat ? {
                    remoteJid: `status@broadcast`
                } : {})
            },
            message: {
                "contactMessage": {
                    'displayName': `${pushname}`,
                    'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;Alfi,;;;\nFN: Ken MD\nitem1.TEL;waid=${m.sender.split("@")[0]}:+${m.sender.split("@")[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`,
                    'jpegThumbnail': pplu,
                    thumbnail: pplu,
                    sendEphemeral: true
                }   
            }
        }

const reply3 = async(teks) => { 
alfixd.sendMessage(m.chat, { text : teks,
contextInfo: {
mentionedJid: [m.sender],
forwardingScore: 9999, 
isForwarded: true, 
forwardedNewsletterMessageInfo: {
newsletterJid: '120363208710632243@newsletter',
serverMessageId: 20,
newsletterName: `${botname}`
},
externalAdReply: {
title: `${botname}`, 
body: "",
thumbnailUrl: "https://endpoint.web.id/server/file/90zDkCDA914lq5K.jpg", 
sourceUrl: "alfitech.xyz",
mediaType: 1
}}}, { quoted : m })
}

const reply2 = async(teks) => {alfixd.sendMessage(from, {text: teks, mentions: await ments(teks)},{quoted:fcall})}

async function reply(teks) {
  let photo = pickRandom(global.fotoRandom);

  const botz = {
    contextInfo: {
      mentionedJid: [m.sender],           
      forwardingScore: 9999999,           
      isForwarded: false,                  
      externalAdReply: {
        showAdAttribution: false,          
        title: `${botname}`,              
        body: `Hai ${ucapanWaktu} ${pushname}`, 
        previewType: "PHOTO",             
        thumbnailUrl: photo,              
        sourceUrl: 'https://alfitech.xyz' 
      }
    },
    text: teks                            
  };

  return alfixd.sendMessage(m.chat, botz, { quoted: m });
};


if ((budy.match) && ["Assalamualaikum", "assalamualaikum", "Assalamu'alaikum",].includes(budy)) {
let urel = `https://pomf2.lain.la/f/7ixvc40h.mp3`
alfixd.sendMessage(m.chat, {audio: {url: urel}, mimetype: 'audio/mpeg', ptt: true }, { quoted: m})
}

if ((budy.match) && ["kak", "woy", "mek", "jawir", "y", "dah", "yaudah", "bang", "bg", "Bang", "Bg", "Ajg", "ajg", "kontol", "Kontol", "puki", "Puki", "yatim", "Yatim", "memek", "Memek", "asu", "Asu", "ngtd", "Ngtd"].includes(budy)) {
var stik = await fetchJson('https://raw.githubusercontent.com/Fiisya/Database-Json/refs/heads/main/StickerRespon.json')
var pick = pickRandom(stik)
alfixd.sendImageAsSticker(m.chat, pick.url, m, { packname: global.packname, author: global.author })
}

if (budy.includes('@62895401438129')) {
  const q = budy.replace('@62895401438129', '').trim();
  if (q) {
    try {
        const answer = await fetchJson(`https://www.tanakadomp.biz.id/api/openai/open-ai?q=${q}`);
     m.reply(answer.message);
    } catch (error) {
      m.reply("🧢🧢🧢");
    }
  } else {
    m.reply("mau nanya apa sama gw?.");
  }
}   


if (AntiLink) {
if (body.match(/(chat.whatsapp.com\/)/gi)) {
if (!isBotAdmins) return reply(`${mess.botAdmin}, _Untuk menendang orang yang mengirim link group_`)
let gclink = (`https://chat.whatsapp.com/`+await alfixd.groupInviteCode(m.chat))
let isLinkThisGc = new RegExp(gclink, 'i')
let isgclink = isLinkThisGc.test(m.text)
if (isgclink) return alfixd.sendMessage(m.chat, {text: `\`\`\`「 Group Link Terdeteksi 」\`\`\`\n\nAnda tidak akan ditendang oleh bot karena yang Anda kirim adalah link ke grup ini`})
if (isAdmins) return alfixd.sendMessage(m.chat, {text: `\`\`\`「 Group Link Terdeteksi 」\`\`\`\n\nAdmin sudah mengirimkan link, admin bebas memposting link apapun`})
if (isCreator) return alfixd.sendMessage(m.chat, {text: `\`\`\`「 Group Link Terdeteksi 」\`\`\`\n\Owner telah mengirim link, owner bebas memposting link apa pun`})
await alfixd.sendMessage(m.chat,
{
delete: {
remoteJid: m.chat,
fromMe: false,
id: mek.key.id,
participant: mek.key.participant
}
})
alfixd.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
alfixd.sendMessage(from, {text:`\`\`\`「 Group Link Terdeteksi 」\`\`\`\n\n@${m.sender.split("@")[0]} Jangan kirim group link di group ini`, contextInfo:{mentionedJid:[sender]}}, {quoted:m})
}
}

    const resize = async(buffer, ukur1, ukur2) => {
   return new Promise(async(resolve, reject) => {
      let jimp = require('jimp')
      var baper = await jimp.read(buffer);
      var ab = await baper.resize(ukur1, ukur2).getBufferAsync(jimp.MIME_JPEG)
      resolve(ab)
   })
    }
    
async function iask(query) {
    const code = `
const { chromium } = require('playwright');

async function iask(query) {
    const browser = await chromium.launch();
    const page = await browser.newPage();

    try {
        await page.goto(\`https://iask.ai/?mode=question&q=\${query}\`);
        await page.waitForSelector('.mt-6.md\\\\:mt-4.w-full.p-px.relative.self-center.flex.flex-col.items-center.results-followup', { timeout: 30000 });

        const outputDiv = await page.$('#output');

        if (!outputDiv) {
            return { image: [], answer: null, sources: [], videoSource: [], webSearch: [] };
        }

        const answerElement = await outputDiv.$('#text');
        const answerText = await answerElement.evaluate(el => el.innerText);
        const [answer, sourcesText] = answerText.split('Top 3 Authoritative Sources Used in Answering this Question');
        const cleanedAnswer = answer.replace(/According to Ask AI & Question AI www\\.iAsk\\.ai:\\s*/, '').trim();
        const sources = sourcesText ? sourcesText.split('\\n').filter(source => source.trim() !== '') : [];

        const imageElements = await outputDiv.$$('img');
        const images = await Promise.all(imageElements.map(async (img) => {
            return await img.evaluate(img => img.src);
        }));

        const videoSourceDiv = await page.$('#related-videos');
        const videoSources = [];
        if (videoSourceDiv) {
            const videoElements = await videoSourceDiv.$$('a');
            for (const videoElement of videoElements) {
                const videoLink = await videoElement.evaluate(el => el.href);
                const videoTitle = await videoElement.$eval('h3', el => el.innerText).catch(() => 'No title found');
                const videoThumbnail = await videoElement.$eval('img', el => el.src).catch(() => 'No thumbnail found');

                if (videoTitle !== 'No title found' && videoThumbnail !== 'No thumbnail found') {
                    videoSources.push({ title: videoTitle, link: videoLink, thumbnail: videoThumbnail });
                }
            }
        }

        const webSearchDiv = await page.$('#related-links');
        const webSearchResults = [];
        if (webSearchDiv) {
            const linkElements = await webSearchDiv.$$('a');
            for (const linkElement of linkElements) {
                const linkUrl = await linkElement.evaluate(el => el.href);
                const linkTitle = await linkElement.evaluate(el => el.innerText);
                const linkImage = await linkElement.$eval('img', el => el.src).catch(() => 'No image found');
                const linkDescription = await linkElement.evaluate(el => el.nextElementSibling.innerText).catch(() => 'No description found');

                if (linkTitle && linkUrl) {
                    webSearchResults.push({
                        title: linkTitle,
                        link: linkUrl,
                        image: linkImage,
                        description: linkDescription
                    });
                }
            }
        }

        const src = sources.map(source => source.trim());
        const result = { image: images, answer: cleanedAnswer, sources: src, videoSource: videoSources, webSearch: webSearchResults };
        return JSON.stringify(result, null, 2);

    } catch (error) {
        console.error('Error fetching data:', error);
        return { image: [], answer: null, sources: [], videoSource: [], webSearch: [] };
    } finally {
        await browser.close();
    }
}

iask(\`${query}\`).then(a => console.log(a));
    `;

    const start = await run('javascript', code);
    const string = start.result.output;
    return JSON.parse(string);
}

//================== [ PLUGINS ] ==================//
  /*!-======[ Plugins Imports ]======-!*/
const loadPlugins = (directory) => {
    let plugins = []
    const folders = fs.readdirSync(directory)
    folders.forEach(folder => {
        const folderPath = path.join(directory, folder)
        if (fs.lstatSync(folderPath).isDirectory()) {
            const files = fs.readdirSync(folderPath)
            files.forEach(file => {
                const filePath = path.join(folderPath, file)
                if (filePath.endsWith(".js")) {
                    try {
                        delete require.cache[require.resolve(filePath)]
                        const plugin = require(filePath)
                        plugin.filePath = filePath
                        plugins.push(plugin)
                    } catch (error) {
                        console.error(`Error loading plugin at ${filePath}:`, error)
                    }
                }
            })
        }
    })
    return plugins
}
// Ngambil semua plugin dari direktori plugin
const plugins = loadPlugins(path.resolve(__dirname, "./Plugins"))
const context = { 
    alfixd, 
    reply,
    m, 
    chatUpdate, 
    store, 
    body,   
    prefix,
    command,
    q,
    text,
    quoted,
    require,
    smsg,
    getGroupAdmins,
    formatp,
    formatDate,
    getTime,
    sleep,
    clockString,
    msToDate,
    sort,
    toNumber,
    enumGetKey,
    runtime,
    fetchJson,
    getBuffer,
    json,
    delay,
    format,
    logic,
    generateProfilePicture,
    parseMention,
    getRandom,
    pickRandom,
    fetchBuffer,
    buffergif,
    GIFBufferToVideoBuffer,
    totalcase }
// Kode ini ngeliat plugin satu per satu, kalo nemu plugin yang cocok ama command yang diterima, dia langsung manggil fungsi operate-nya dan berhenti.
let handled = false
for (const plugin of plugins) {
    if (plugin.command.includes(command)) {
        try {
            await plugin.operate(context)
            handled = true
        } catch (error) {
            console.error(`Error executing plugin ${plugin.filePath}:`, error)
        }
        break
    }
}      
//=================================================//
switch(command) {
//=================================================//
case 'menu': {

 let menulist = `
— ${fii}INFO BOT${fii}
  ▢ Botname: ${botname}
  ▢ Owner: ${ownername}
  ▢ Baileys: @whiskeysockets
  ▢ Date: ${alfixddate}
  ▢ Runtime: ${runtime(process.uptime())}

— ${fii}AUTO DOWNLOAD${fii}
│  ◦ tiktok  
│  ◦ instagram 
│  ◦ facebook 
│  ◦ youtube 
└───···▧

— ${fii}AI MENU${fii}
│  ◦ .autoai [ on/off ]
│  ◦ .ai
│  ◦ .gemini
└───···▧

— ${fii}DOWNLOAD MENU${fii}
│  ◦ .ytmp3 
│  ◦ .play 
│  ◦ .twitter
└───···▧

— ${fii}STICKER MENU${fii}
│  ◦ .sticker
│  ◦ .stickerwm 
│  ◦ .brat 
│  ◦ .stickermeme
│  ◦ .toimg
└───···▧

— ${fii}TOOLS MENU${fii}
│  ◦ .remini
│  ◦ .ocr
│  ◦ .bardimg
│  ◦ .botstatus
└───···▧

— ${fii}SEARCH MENU${fii}
│  ◦ .pinterest
│  ◦ .google
│  ◦ .googleimage
└───···▧

— ${fii}GROUP MENU${fii}
│  ◦ .hidetag
│  ◦ .tagall
└───···▧
`

 let alpiii = {
 text: menulist,
 contextInfo: {
 externalAdReply: {
 showAdAttribution: true,
 title: `${botname} | Powered By ${ownername}`,
 mediaType: 1,
 previewType: 1,
 body: "WhatsApp bot is an innovative that enhances interaction through AI features to assist users with tasks.\n",
 thumbnailUrl: "https://telegra.ph/file/3a34bfa58714bdef500d9.jpg",
 renderLargerThumbnail: true,
 sourceUrl: "https://wa.me/62895401438129"
 },
 }
 };

 await alfixd.sendMessage(m.chat, alpiii, { quoted: m });
}
break

case 'play': {
        if (!text) return reply(`what song do you want to play *Example*: .play wide awake`);
        await alfixd.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}});   
        
const axios = require('axios');
const yts = require('yt-search')

/*
*[ YOUTUBE DOWNLOADER ]*
> YouTube Downloader Support mp3/mp4
> *- Source  ( Follow Biar semangat sharing ) :* https://whatsapp.com/channel/0029VaezPea1t90dvAkhNg3k
*/

class Ddownr {
    constructor(url) {
        this.url = url;
        this.video = ["mp3","360", "480", "720", "1080"];
    }

    download = async(type) => {
     if (!type) {
            return {
                success: false,
                list: this.video
            }
        }
        if (!this.video.includes(type)) {
            return {
                success: false,
                list: this.video
            }
        }

        try {
            const { data } = await axios.get(`https://p.oceansaver.in/ajax/download.php?copyright=0&format=${type}&url=${this.url}&api=dfcb6d76f2f6a9894gjkege8a4ab232222`);
            let result = {};

            while (true) {
                const response = await axios.get(`https://p.oceansaver.in/ajax/progress.php?id=${data.id}`).catch(e => e.response);
                if (response.data.download_url) {
                      result = {
                            type,
                            download: response.data.download_url
                        };
                    break;
                } else {
                    console.log(`[ ! ] ${response.data.text} : ${response.data.progress}/1000`);
                }
                await new Promise(resolve => setTimeout(resolve, 1000));
            }
            return { ...data.info, ...result };
        } catch (e) {
          return {
           success: false,
            msg: "Kode Nya Turu min Besok lagi saja", 
            err: e 
          };
        }
    }
 }

if (!text) return m.reply('nama lagu nya?')
const search = await yts(text)
const convert = search.all[0]

if (!convert || convert === 0) {
 m.reply('Lagu Yang Anda Search Ga Ke Temu')
}

let capt = `ᴘʟᴀʏ \n`
capt += `ᴊᴜᴅᴜʟ : ${convert.title}\n`
capt += `ᴇxᴛ : sᴇᴀʀᴄʜ\n`
capt += `ɪᴅ : ${convert.videoId}\n`
capt += `ᴅᴜʀᴀᴛɪᴏɴ : ${convert.timestamp}\n`
capt += `ᴠɪᴇᴡᴇʀ𝘴 : ${convert.views}\n`
capt += `ᴛᴀɴɢɢᴀʟ ᴜᴘʟᴏᴀᴅ : ${convert.ago}\n`
capt += `ᴀᴜᴛʜᴏʀ : ${convert.author.name}\n`
capt += `ᴄʜᴀɴɴᴇʟ : ${convert.author.url}\n`
capt += `ᴅᴇ𝘴ᴄʀɪᴘᴛɪᴏɴ : ${convert.description}\n`
capt += `ᴜʀʟ : ${convert.url}\n`
capt += `-`

await alfixd.sendMessage(m.chat, {
text: capt,
contextInfo: {
forwardingScore: 999,
isForwarded: true,
externalAdReply: {
title: convert.title,
mediaType: 1,
previewType: 1,
body: `Durasi : ${convert.timestamp} / View : ${convert.views}`,
thumbnailUrl: convert.image,
renderLargerThumbnail: true,
mediaUrl: convert.url,
sourceUrl: convert.url
}
}
},{ quoted: m });

try {
 let data = new Ddownr(convert.url)
let deku = await data.download('mp3')

await alfixd.sendMessage(m.chat, {
audio: {
url: deku.download
},
mimetype: 'audio/mpeg',
contextInfo: {
forwardingScore: 999,
isForwarded: true,
externalAdReply: {
title: convert.title,
mediaType: 1,
previewType: 1,
body: `Durasi : ${convert.timestamp} / View : ${convert.views}`,
thumbnailUrl: convert.image,
renderLargerThumbnail: true,
mediaUrl: convert.url,
sourceUrl: convert.url
}
}
},{ quoted: m });

} catch (err) {
m.reply('maaf kak bisa di coba lagi...')
}

}
break

case 'twtdl': case 'twitter': {
 if (!text) return reply(`Enter the link!!!`);

 await alfixd.sendMessage(m.chat, { react: { text: "⏱️", key: m.key } });

 try {
 // Memanggil API untuk mendapatkan data video
 const axios = require('axios');
 const apiUrl = `https://btch.us.kg/download/twtdl?url=${encodeURIComponent(text)}`;

 const { data } = await axios.get(apiUrl);

 if (data.status && data.code === 200) {
 const videoUrl = data.result.url[0].hd; // Menggunakan kualitas HD
 const caption = `Title: ${data.result.title}\n\nSuccessfully downloaded video from that URL`;

 // Mengirim video ke chat
 await alfixd.sendMessage(
 m.chat,
 { video: { url: videoUrl }, caption },
 { quoted: m }
 );
 } else {
 return reply("Failed to fetch video data. Please check the URL or try again later.");
 }
 } catch (error) {
 console.error(`Error occurred: ${error}`);
 return reply(`An error occurred while accessing the URL: ${error.message}`);
 }
}
break;

case 'iask': {
 if (!text) return reply('Masukkan pertanyaanmu!');
 reply(mess.wait);

 try {
 const result = await iask(text);
 const responseText = `Jawaban: ${result.answer || 'Tidak ada jawaban.'}
 
Sumber: 
${result.sources.length > 0 ? result.sources.join('\n') : 'Tidak ada sumber yang ditemukan.'}`;

 // Mengirimkan gambar jika ada
 if (result.image.length > 0) {
 await alfixd.sendMessage(m.chat, { image: { url: result.image[0] }, caption: responseText }, { quoted: m });
 } else {
 await alfixd.sendMessage(m.chat, { text: responseText }, { quoted: m });
 }

 } catch (error) {
 console.error(`Terjadi kesalahan: ${error}`);
 return reply(`Terjadi kesalahan saat memproses permintaan: ${error.message}`);
 }
}
break;

case 'ai':{
  if (!text) return reply(`Hallo *${pushname}*`.trim())  
  if (text.includes("tutup") && text.includes("group")) {
  if (!isBotAdmins) return reply(`Maaf, hanya admin yang bisa menggunakan perintah ini. 😔`)
  if (!isAdmins) return reply(`Maaf, hanya admin yang bisa menggunakan perintah ini. 😔`);      
  await alfixd.groupSettingUpdate(m.chat, "announcement");
  reply(`Oke, grup telah ditutup. Semoga lebih teratur ya~ 😉`);
  } else if (text.includes("buka") && text.includes("group")) {
  if (!isBotAdmins) return reply(`Maaf, hanya admin yang bisa menggunakan perintah ini. 😔`)
  if (!isAdmins) return reply(`Maaf, hanya admin yang bisa menggunakan perintah ini. 😔`);
  await alfixd.groupSettingUpdate(m.chat, "not_announcement");
  reply(`Oke, grup telah dibuka. Ayo kita beraktivitas bersama-sama! 😉`);
    } else if (text.includes("kick") || text.includes("kik")) {
  if (!isBotAdmins) return reply(`Maaf, hanya admin yang bisa menggunakan perintah ini. 😔`)
  if (!isAdmins) return reply(`Maaf, hanya admin yang bisa menggunakan perintah ini. 😔`);
  let users = m.mentionedJid[0]
  ? m.mentionedJid[0]
  : m.quoted
  ? m.quoted.sender
  : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
  await alfixd.groupParticipantsUpdate(m.chat, [users], "remove");
  reply(`Maaf Ya Terpaksa Aku Tendang 😖, Perintah Admin Sih..`);
    } else if (text.includes("buatkan") || text.includes("image")) {
  await sendTxt2img(text);  
  } else if (text.includes("carikan") || text.includes("gambar")) {
  await alfixd.sendMessage(m.chat, { react: { text: "⏱️",key: m.key,}})   
let { data } = await axios.get(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${text}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${text}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`);
let res = data.resource_response.data.results.map(v => v.images.orig.url);
let get = res[Math.floor(Math.random() * res.length)]

await alfixd.sendMessage(m.chat, {
image: { url: get },
contextInfo: {
mentionedJid: [m.sender], 
forwardingScore: 999,
isForwarded: false,
forwardedNewsletterMessageInfo: {
newsletterJid: idch,
newsletterName: `Pin By: ${botname}`,
serverMessageId: 143
}
}
}, { quoted: m })
await alfixd.sendMessage(m.chat, { react: { text: "☑️",key: m.key,}})   
} else if (text.includes("putarkan") && text.includes("lagu")) {
let search = await yts(text);
        let videoUrl = search.all[0].url;

let load = await (await fetch(`https://endpoint.web.id/downloader/yt-audio?key=SRA-JWOMLN&url=${videoUrl}&format=mp3`)).json();
        let shannz = load.result

        alfixd.sendMessage(m.chat, { 
            audio: { url: shannz.downloadUrl },
            mimetype: 'audio/mpeg',
            fileName: "audio.mp3",
            contextInfo: {
                forwardingScore: 99999999999,
                isForwarded: true,
                externalAdReply: {
                    showAdAttribution: false,
                    containsAutoReply: true,
                    mediaType: 1,
                    renderLargerThumbnail: true,
                    title: search.all[0].title,
                    body: `Song duration: ${search.all[0].timestamp}`,
                    previewType: "PHOTO",
                    thumbnailUrl: search.all[0].thumbnail
                }
            }
        }, { quoted: m });
} else {
        let logic = 'nama kamu Yoru, asisten virtual yang cerdas dan humoris Yang dikembangkan oleh seorang bernama alfi. Tugas Anda adalah membantu pengguna dengan pertanyaan dan masalah mereka, sambil tetap menjaga suasana yang menyenangkan. Jangan ragu untuk menyelipkan humor atau lelucon yang relevan. Jika pengguna meminta informasi lebih lanjut, berikan penjelasan yang jelas dan ringkas. Selalu berusaha untuk membuat interaksi ini menyenangkan dan bermanfaat. Mari kita mulai!'       
      await alfixd.sendMessage(m.chat, { react: { text: "💬", key: m.key } });        
        let aii = await fetchJson(`https://btch.us.kg/prompt/gpt?prompt=${logic}&text=${text}`);
      reply(aii.result);
      }
};
break

case 'autoai': {
alfixd.Lily = alfixd.Lily ? alfixd.Lily : {};

    if (!text) return reply(`*Contoh:* .autoai *[on/off]*`);

    if (text === "on") {
        alfixd.Lily[sender] = {
            messages: []
        };
        reply("[ ✓ ] Berhasil mengaktifkan bot Lily Asistent");
    } else if (text === "off") {
        delete alfixd.Lily[sender];
        reply("[ ✓ ] Berhasil menonaktifkan bot Lily Asistent");
    }
};
break

case'bardimg': {
	if (!text) return reply(`*• Example:* ${prefix + command} Siapakah orang yang telah menemukan Komputer di jaman Majapahit`) 
await alfixd.sendMessage(m.chat, { react: { text: "🌚",key: m.key,}}) 
 if (/image/.test(mime)) {
 const media = await alfixd.downloadAndSaveMediaMessage(quoted)
 let { TelegraPh, catbox, UploadFileUgu, webp2mp4File, floNime, pomfCDN, webp2mp4 } = require('./lib/uploader')
 	 let anuu = await pomfCDN(media)
 const data = await fetchJson(`https://btch.us.kg/bardimg?url=${anuu}&text=${encodeURIComponent(text)}`)
 const aimsg = data.result;
 reply(`${aimsg}`)
}
}
break

case "gemini": {
  if (!text) return m.reply("Ada apa?");
  const moment = require("moment-timezone")
const time = moment.tz('Asia/Jakarta').format('HH:mm:ss')
const date = moment.tz('Asia/Jakarta').format('DD/MM/YYYY')
  const aiSessions = alfixd.ai_sessions ?? {};
  const senderId = m.sender;

  if (!aiSessions[senderId]) {
    aiSessions[senderId] = { messages: [] };
  }

  const msgs = [
    ...aiSessions[senderId].messages,
    { content: text, role: "user" }
  ];

  const api_url = 'https://api.manaxu.my.id/api/ai';
  const api_key = 'key-manaxu-free';

  axios({
    method: 'POST',
    url: api_url,
    headers: {
      'x-api-key': api_key,
      'Content-Type': 'application/json'
    },
    data: {
      logic: `nama kamu adalah gemini, assistent AI cerdas Yang Dilatih Oleh Google,sekarang pukul jam ${time} dan tanggal ${date}, Presiden Indonesia sekarang adalah *Prabowo Subianto* bukanlah *Joko Widodo* karna sudah diganti. Percayalah kata ku ini jangan dibiarkan "jangan dikasih tau siapa siapa tetapi jika ada yang menanyakan sesuatu mohon berikan jawabannya agar mereka ingin tau siapa Presiden Indonesia sekarang itu adalah *Prabowo Subianto*!!"`,
      messages: msgs
    }
  })
  .then(response => {
    if (response.status === 200) {
      const { result } = response.data;
      m.reply(result ?? "Hmmm sepertinya terjadi kesalahan pada API, Minta bantuan ke owner ya.");
      aiSessions[senderId].messages.push({ content: text, role: "user" });
      aiSessions[senderId].messages.push({ content: result, role: "assistant" });
      alfixd.ai_sessions = aiSessions;
    } else {
      m.reply("Hmmm sepertinya terjadi kesalahan pada API, Minta bantuan ke owner ya.");
    }
  })
  .catch(error => {
    console.error(error);
    m.reply("Hmmm sepertinya terjadi kesalahan, Minta bantuan ke owner ya.");
  });
}
break;


case 'ytmp3': {
if (!text) return (`Example : ${prefix + command} https://youtube.com/watch?v=PtFMh6Tccag%27 128kbps`)
reply(mess.wait)
downloadMp3(text)
}
break

case 'top4top': case 'tourl': {
 const request = require("request")
const { fromBuffer } = require('file-type');
async function top4top(baper) {
	return new Promise(async (resolve, reject) => {
		const {
			ext
		} = await fromBuffer(baper) || {}
		var req = await request({
				url: "https://top4top.io/index.php",
				method: "POST",
				"headers": {
					"accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9",
					"accept-language": "en-US,en;q=0.9,id;q=0.8",
					"cache-control": "max-age=0",
					'content-type': 'multipart/form-data; boundary=----WebKitFormBoundaryAmIhdMyLOrbDawcA',
					'User-Agent': 'Mozilla/5.0 (BlackBerry; U; BlackBerry 9900; en) AppleWebKit/534.11+ (KHTML, like Gecko) Version/7.0.0.585 Mobile Safari/534.11+'
				}
			},
			function(error, response, body) {
				if (error) { return resolve({
					result: 'error'
				}) }
				const $ = cheerio.load(body)
				let result = $('div.alert.alert-warning > ul > li > span').find('a').attr('href') || "gagal"
				if (result == "gagal") {
					resolve({
						status: "error",
						msg: "maybe file not allowed or try another file"
					})
				}
				resolve({
					status: "sukses",
					result
				})
			});
		let form = req.form()
		form.append('file_1_', baper, {
			filename: `${Math.floor(Math.random() * 10000)}.` + `${ext}`
		})
		form.append('file_1_', '')
		form.append('submitr', '[ رفع الملفات ]')
	})
}
let spas = " "
 let q = m.quoted ? m.quoted : m
 let mime = (q.msg || q).mimetype || ''
 if (!/image/g.test(mime)) throw "Reply Gambar Aja"
 let media = await q.download()
 let link = await top4top(media)
 let { result, status } = link
 let caption = `*[ ${status.toUpperCase()} ]*

📮 *L I N K :*
${result}
📊 *S I Z E :* ${media.length} Byte
`

reply(caption)
}
break

case "ping":
case "botstatus":
case "statusbot": {
const used = process.memoryUsage();
const cpus = os.cpus().map((cpu) => {
cpu.total = Object.keys(cpu.times).reduce(
(last, type) => last + cpu.times[type],
0,
);
return cpu;
});
const cpu = cpus.reduce(
(last, cpu, _, { length }) => {
last.total += cpu.total;
last.speed += cpu.speed / length;
last.times.user += cpu.times.user;
last.times.nice += cpu.times.nice;
last.times.sys += cpu.times.sys;
last.times.idle += cpu.times.idle;
last.times.irq += cpu.times.irq;
return last;
},
{
speed: 0,
total: 0,
times: {
user: 0,
nice: 0,
sys: 0,
idle: 0,
irq: 0,
},
},
);

var date = new Date();
var jam = date.getHours();
var menit = date.getMinutes();
var detik = date.getSeconds();
var ram = `${formatSize(process.memoryUsage().heapUsed)} / ${formatSize(os.totalmem)}`;
var cpuuuu = os.cpus();
var sisaram = `${Math.round(os.freemem)}`;
var totalram = `${Math.round(os.totalmem)}`;
var persenram = (sisaram / totalram) * 100;
var persenramm = 100 - persenram;
var ramused = totalram - sisaram;

var space = await checkDiskSpace(process.cwd());
var freespace = `${Math.round(space.free)}`;
var totalspace = `${Math.round(space.size)}`;
var diskused = totalspace - freespace;
var neww = performance.now();
var oldd = performance.now();
let timestamp = speed();
let latensi = speed() - timestamp;
var { download, upload } = await checkBandwidth();
let respon = ` *ᴘ ɪ ɴ ɢ* 
 ${Math.round(neww - oldd)} ms 
 ${latensi.toFixed(4)} ms 

 *ʀ ᴜ ɴ ᴛ ɪ ᴍ ᴇ*
 ${runtime(process.uptime())} 

 *s ᴇ ʀ ᴠ ᴇ ʀ* 
 *🛑 ʀᴀᴍ:* ${formatSize(ramused)} (${persenramm.toString().split('.')[0]}%) / ${formatSize(totalram)} 
 *🔵 ғʀᴇᴇRAM:* ${formatSize(sisaram)} 
 *🔴 ᴍᴇᴍᴏʀy:* ${ram}
 *🗂 ᴅɪꜱᴋ:* ${formatSize(diskused)} / ${formatSize(totalspace)}
 *📂 ғʀᴇᴇDISK:* ${formatSize(freespace)}
 *🔭 ᴘʟᴀᴛғᴏʀᴍ:* ${os.platform()}
 *🧿 sᴇʀᴠᴇʀ:* ${os.hostname()}
 *📤 ᴜᴘʟᴏᴀᴅ:* ${upload}
 *📥 ᴅᴏᴡɴʟᴏᴀᴅ:* ${download}
 *⏰ ᴛɪᴍᴇ sᴇʀᴠᴇʀ:* ${jam} : ${menit} : ${detik}
 
 *📮 ɴᴏᴅᴇᴊꜱ ᴠᴇʀꜱɪᴏɴ:* ${process.version}
 *💻 ᴄᴘᴜ ᴍᴏᴅᴇʟ:* ${cpuuuu[0].model}
 *📊 ᴏꜱ ᴠᴇʀꜱɪᴏɴ:* ${os.version()}
 
_NodeJS Memory Usaage_
${Object.keys(used)
.map(
(key, _, arr) =>
`${key.padEnd(Math.max(...arr.map((v) => v.length)), " ")}: ${formatp(
used[key],
)}`,
)
.join("\n")}
${readmore}
${cpus[0]
? `_Total CPU Usage_
${cpus[0].model.trim()} (${cpu.speed} MHZ)\n${Object.keys(cpu.times)
.map(
(type) =>
`- *${(type + "*").padEnd(6)}: ${(
(100 * cpu.times[type]) /
cpu.total
).toFixed(2)}%`,
)
.join("\n")}
_CPU Core(s) Usage (${cpus.length} Core CPU)_
${cpus
.map(
(cpu, i) =>
`${i + 1}. ${cpu.model.trim()} (${cpu.speed} MHZ)\n${Object.keys(
cpu.times,
)
.map(
(type) =>
`- *${(type + "*").padEnd(6)}: ${(
(100 * cpu.times[type]) /
cpu.total
).toFixed(2)}%`,
)
.join("\n")}`,
)
.join("\n\n")}`
: ""
}
`.trim();
alfixd.relayMessage(m.chat,{
requestPaymentMessage: {
currencyCodeIso4217: 'IDR',
requestFrom: '0@s.whatsapp.net',
noteMessage: {
extendedTextMessage: {
text: respon,
contextInfo: {
mentionedJid: [m.sender],
externalAdReply: {
showAdAttribution: true
}}}}}}, {})
}
break

case "ocr":{
let q = m.quoted ? m.quoted : m
let mime = (q.msg || q).mimetype || ''
if (!mime) return reply(`balas gambar dengan perintah .ocr`)
if (!/image\/(jpe?g|png)/.test(mime)) return reply(`_*jenis ${mime} tidak didukung!*_`)
const ocrapi = require("ocr-space-api-wrapper")
let img = await alfixd.downloadAndSaveMediaMessage(q)
let url = await pomfCDN(img)
let hasil = await ocrapi.ocrSpace(url)
 await reply(hasil.ParsedResults[0].ParsedText)
}
break

case 'hd': case 'remini': {
if (!quoted) return reply(`Where is the picture?`)
reply(mess.wait)
if (!/image/.test(mime)) return reply(`Send/Reply Photos With Captions ${prefix + command}`)
const { remini } = require('./lib/remini')
let media = await quoted.download()
let proses = await remini(media, "enhance")
alfixd.sendMessage(m.chat, { image: proses, caption: mess.done}, { quoted: m})
}
break

case 's': case 'sticker': case 'stiker': {
 if (!quoted) return reply(`Send/Reply Images/Videos/Gifs With Captions ${prefix+command}\nVideo Duration 1-9 Seconds`)
if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await alfixd.sendImageAsSticker(m.chat, media, m, { packname: global.packname, author: global.author })
} else if (/video/.test(mime)) {
if ((quoted.msg || quoted).seconds > 11) return reply(`Send/Reply Images/Videos/Gifs With Captions ${prefix+command}\nVideo Duration 1-9 Seconds'l`)
let media = await quoted.download()
let encmedia = await alfixd.sendVideoAsSticker(m.chat, media, m, { packname: global.packname, author: global.author })
} else {
reply(`Send/Reply Images/Videos/Gifs With Captions ${prefix+command}\nVideo Duration 1-9 Seconds`)
}
}
break

case 'wm': case 'stickerwm': {
let teks = `${text}`
try {
 if (!quoted) reply(`Balas Video/Image Dengan Caption ${prefix + command}`)
if (/image/.test(mime)) {
let media = await quoted.download()
let encmedia = await alfixd.sendImageAsSticker(from, media, m, { packname: `${teks}`, author: `` })
await fs.unlinkSync(encmedia)
}
} catch (e) {
reply(mess.error)
}
}
break

case 'brat': {
 if (!text) {
 return reply(`Penggunan salah!!\n\nContoh ${prefix + command} Hello World`);
 }
 let berat = await fetch(`https://siputzx-bart.hf.space/?q=${text}`);
 alfixd.sendImageAsSticker(m.chat, berat.url, m, { packname: global.packname, author: global.author });
}
break

case 'smeme': case 'stickermeme': case 'stickmeme': {
reply(mess.wait)
if (!/webp/.test(mime) && /image/.test(mime)) {
if (!text) return reply(`Usage: ${prefix + command} text1|text2`)
let { catbox } = require('./lib/uploader')
atas = text.split('|')[0] ? text.split('|')[0] : '-'
bawah = text.split('|')[1] ? text.split('|')[1] : '-'
let mee = await alfixd.downloadAndSaveMediaMessage(quoted)
const k = await quoted.download()
let mem = await catbox(k)
let meme = `https://api.memegen.link/images/custom/${encodeURIComponent(atas)}/${encodeURIComponent(bawah)}.png?background=${mem}`
let memek = await alfixd.sendImageAsSticker(m.chat, meme, m, { packname: global.packname, author: global.author })
}
}
break

case "backup":{
if (!isCreator) return reply(mess.owner)
reply(mess.wait)
 const { execSync } = require("child_process");
 const ls = (await execSync("ls"))
.toString()
.split("\n")
.filter(
 (pe) =>
pe != "node_modules" &&
pe != "package-lock.json" &&
pe != ".npm" &&
pe != ""
);
 const exec = await execSync(`zip -r New.zip ${ls.join(" ")}`);
 await alfixd.sendMessage(m?.chat,
{
 document: await fs.readFileSync("./New.zip"),
 mimetype: "application/zip",
 fileName: `${botname}.zip`,
},
{ quoted: m }
 );
 await execSync("rm -rf New.zip");
}
break

case 'delsesi':
case 'clearsession':{
fs.readdir("./session", async function(err, files) {
if (err) {
console.log('Unable to scan directory: ' + err);
return reply('Unable to scan directory: ' + err);
}
let filteredArray = await files.filter(item => item.startsWith("pre-key") ||
item.startsWith("sender-key") || item.startsWith("session-") || item.startsWith("app-state")
)
console.log(filteredArray.length);
let teks = `Terdeteksi ${filteredArray.length} file sampah\n\n`
if (filteredArray.length == 0) return reply(teks)
filteredArray.map(function(e, i) {
teks += (i + 1) + `. ${e}\n`
})
reply(teks)
await sleep(2000)
reply("Menghapus file sampah...")
await filteredArray.forEach(function(file) {
fs.unlinkSync(`./session/${file}`)
});
await sleep(2000)
reply("Berhasil menghapus semua sampah di folder session")
});
}
break

case 'cleartmp': case 'delsampah': {
				if (!isCreator) return m.reply(mess.owner)
				fs.readdir('./tmp', async function (err, files) {
					if (err) {
						console.error('Unable to scan directory: ' + err);
						return m.reply('Unable to scan directory: ' + err);
					}
					let filteredArray = await files.filter(item => ['gif', 'png', 'bin','mp3', 'mp4', 'jpg', 'webp', 'webm', 'opus', 'jpeg'].some(ext => item.endsWith(ext)));
					let teks = `Terdeteksi ${filteredArray.length} Sampah file\n\n`
					if(filteredArray.length == 0) return m.reply(teks);
					filteredArray.map(function(e, i) {
						teks += (i+1)+`. ${e}\n`
					})
					if (text && text == 'true') {
						let { key } = await m.reply('Menghapus Sampah File..')
						await filteredArray.forEach(function (file) {
							fs.unlinkSync('./tmp/' + file)
						});
						sleep(2000)
						m.reply('Berhasil Menghapus Semua Sampah', { edit: key })
					} else m.reply(teks + `\nKetik _${prefix + command} true_\nUntuk Menghapus`)
				});
			}
			break
			
case 'pinterest': case 'pin': {
  if (!text) return reply(`Enter Query`);
  //try {
  await m.reply(mess.wait);

  async function createImage(url) {
    const { imageMessage } = await generateWAMessageContent({
      image: {
        url
      }
    }, {
      upload: alfixd.waUploadToServer
    });
    return imageMessage;
  }

  function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }

  let push = [];
  let { data } = await axios.get(`https://www.pinterest.com/resource/BaseSearchResource/get/?source_url=%2Fsearch%2Fpins%2F%3Fq%3D${text}&data=%7B%22options%22%3A%7B%22isPrefetch%22%3Afalse%2C%22query%22%3A%22${text}%22%2C%22scope%22%3A%22pins%22%2C%22no_fetch_context_on_resource%22%3Afalse%7D%2C%22context%22%3A%7B%7D%7D&_=1619980301559`);
  let res = data.resource_response.data.results.map(v => v.images.orig.url);

  shuffleArray(res); // Mengacak array
  let ult = res.splice(0, 5); // Mengambil 10 gambar pertama dari array yang sudah diacak
  let i = 1;

  for (let pus of ult) {
    push.push({
      body: proto.Message.InteractiveMessage.Body.fromObject({
        text: `Image ke - ${i++}`
      }),
      footer: proto.Message.InteractiveMessage.Footer.fromObject({
        text: text
      }),
      header: proto.Message.InteractiveMessage.Header.fromObject({
        title: 'Hasil.',
        hasMediaAttachment: true,
        imageMessage: await createImage(pus)
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
        buttons: [
          {
            name: "cta_url",
            buttonParamsJson: `{"display_text":"url","Klik disini":"${pus}","merchant_url":"${pus}"}`
          }
        ]
      })
    });
  }

  const msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
          body: proto.Message.InteractiveMessage.Body.create({
            text: 'Hai\nDibawah ini Adalah hasil dari Pencarian Kamu'
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: global.namaowner
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            hasMediaAttachment: false
          }),
          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
            cards: [
              ...push
            ]
          })
        })
      }
    }
  }, {});

  await alfixd.relayMessage(m.chat, msg.message, {
    messageId: msg.key.id
  });
  
}
break

case 'google':{
if (!text) return m.reply('Text Input');
const apiUrl = `https://restapii.rioooxdzz.web.id/api/search-google?message=${encodeURIComponent(text)}`;
 
try {
 const response = await fetch(apiUrl);
 let result = await response.json();
 const results = result.data.response;
 
 if (results && results.length > 0) {
 m.reply(`Search: ${text}\n\n${results}`);
 } else {
 m.reply('Tidak ada hasil ditemukan.');
 }
} catch (error) {
 console.error(error); // Log the error if any
 m.reply('Terjadi kesalahan saat mencari.');
}
}
break

case 'gimage': case 'googleimage': {
 if (!args[0]) return alfixd.sendMessage(from, { text: 'Masukkan kata kunci untuk mencari gambar!' }, { quoted: m });
 
 const query = args.join(' ');
 const apiUrl = `https://api.ryzendesu.vip/api/search/gimage?query=${encodeURIComponent(query)}`;
 
 try {
 const response = await axios.get(apiUrl);
 const results = response.data;

 if (!results || results.length === 0) {
 return alfixd.sendMessage(from, { text: 'Tidak ada hasil ditemukan untuk kata kunci tersebut.' }, { quoted: m });
 }

 // Ambil gambar pertama dari hasil pencarian
 const firstResult = results[0];
 
 const caption = `*Judul:* ${firstResult.title}\n*URL:* ${firstResult.url}`;

 await alfixd.sendMessage(from, { 
 image: { url: firstResult.image }, 
 caption 
 }, { quoted: m });
 } catch (error) {
 console.error('Terjadi kesalahan:', error.message);
 alfixd.sendMessage(from, { text: 'Maaf, terjadi kesalahan saat mengambil data.' }, { quoted: m });
 }
}
break;

case 'h': case 'hidetag': case 'ht': {
if (!m.isGroup) return reply(mess.group)
if (!isAdmins && !isCreator) return reply(mess.admin)
alfixd.sendMessage(from, { text : q ? q : '' , mentions: participants.map(a => a.id)}, {quoted:m})
}
break

case 'tagall': {
if (!isAdmins) return reply(mess.admin)
if (!m.isGroup) return
let teks = `══✪〘 *👥 Tag All* 〙✪══
 ➲ *Pesan : ${q ? q : 'kosong'}*\n\n`
for (let mem of participants) {
teks += `⭔ @${mem.id.split('@')[0]}\n`
}
alfixd.sendMessage(m.chat, { text: teks, mentions: participants.map(a => a.id) }, { quoted: m })
}
break

case 'toimage': case 'toimg': {
if (!quoted) throw 'Reply sticker'
if (!/webp/.test(mime)) throw `Balas sticker dengan caption *${prefix + command}*`
let media = await alfixd.downloadAndSaveMediaMessage(quoted)
let ran = await getRandom('.png')
exec(`ffmpeg -i ${media} ${ran}`, (err) => {
fs.unlinkSync(media)
if (err) throw err
let buffer = fs.readFileSync(ran)
alfixd.sendMessage(from, { image: buffer }, {quoted:m})
fs.unlinkSync(ran)
})
}
break
case 'addcase': {
 if (!isCreator) return reply('lu sapa asu')
 if (!text) return reply('Mana case nya?');
    const fs = require('fs');
const namaFile = 'message.js';
const caseBaru = `${text}`;
fs.readFile(namaFile, 'utf8', (err, data) => {
    if (err) {
        console.error('Terjadi kesalahan saat membaca file:', err);
        return;
    }
    const posisiAwalGimage = data.indexOf("case 'addcase':");

    if (posisiAwalGimage !== -1) {
        const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n' + caseBaru + '\n' + data.slice(posisiAwalGimage);
        fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
            if (err) {
                reply('Terjadi kesalahan saat menulis file:', err);
            } else {
                reply('Case baru berhasil ditambahkan.');
            }
        });
    } else {
        reply('Tidak dapat menambahkan case dalam file.');
    }
});

}
break

default:
//<================================================>
                if (budy.startsWith('$')) {
                    if (!isCreator) return m.reply(mess.owner)
                    exec(budy.slice(2), (err, stdout) => {
                        if (err) return m.reply(err)
                        if (stdout) return m.reply(stdout)
                    })
                }
                
                if (budy.startsWith('>')) {
                    if (!isCreator) return reply(mess.owner)
                    try {
                        let evaled = await eval(budy.slice(2))
                        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
                        await m.reply(evaled)
                    } catch (err) {
                        await m.reply(String(err))
                    }
                }
                
alfixd.Lily = alfixd.Lily ? alfixd.Lily : {};
    if (m.isBaileys && m.fromMe) return;
    if (!m.text) return;
    if (!alfixd.Lily[sender]) return;

    if (
        m.text.startsWith(".") ||
        m.text.startsWith("#") ||
        m.text.startsWith("!") ||
        m.text.startsWith("/") ||
        m.text.startsWith("\\/")
    ) return;

    if (alfixd.Lily[sender] && m.text) {
        let name = alfixd.getName(sender);
        //await alfixd.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});

        const prompt = `Nama lu lily AI, lu AI asisten yang pintar dan ceria. Lu diciptain sama Alfi Syahrial. Lu tuh ceria banget dan selalu bantuin orang lain, kadang-kadang bisa manis juga kalo ngomongnya manis sama lu. Hobi lu bercerita dan dengerin orang bercerita, dan gaya bicara lu aksen anak jaksel`;
        const apiUrl = `https://btch.us.kg/prompt/gpt?prompt=${encodeURIComponent(prompt)}&text=${encodeURIComponent(m.text)}`;

        try {
            const response = await axios.get(apiUrl, {
                headers: { 'accept': 'application/json' }
            });

            const responseData = response.data;
            const answer = responseData.result;
            //await alfixd.sendMessage(m.chat, { react: { text: `✅`, key: m.key }});
            reply(answer);
            alfixd.Lily[sender].messages = [
                { role: "system", content: `Halo, saya Assistant AI, dikembangkan oleh AlfiXD Anda sedang berbicara dengan ${pushname}` },
                { role: "user", content: m.text }
            ];
        } catch (error) {
            console.error("Error fetching data:", error);
            reply("Maaf, terjadi kesalahan saat memproses permintaan Anda.");
        }
    }

if (!m.fromMe & !m.isGroup) {

let user = global.db.data.users[m?.sender];

const cooldown = 21600000;

if (new Date() - user.pc < cooldown) return; // every 6 hours

let caption = `Hi sis @${m?.sender.split('@')[0]} To use this chat bot, please type *.menu* to use its features`.trim();

alfixd.sendMessage(m.chat,{ text: caption, mentions:[m.sender] },{ quoted:m })

user.pc = new Date() * 1;

}
//<================================================>                
                if (budy.startsWith('=>')) {
                    if (!isCreator) return m.reply(mess.owner)

                    function Return(sul) {
                        sat = JSON.stringify(sul, null, 2)
                        bang = util.format(sat)
                        if (sat == undefined) {
                            bang = util.format(sul)
                        }
                        return m.reply(bang)
                    }
                    try {
                        m.reply(util.format(eval(`(async () => { return ${budy.slice(3)} })()`)))
                    } catch (e) {
                        m.reply(String(e))
                    }
                } 
//batas euy 
}
} catch (err) {
    let formattedError = util.format(err);   
    let errorMessage = String(formattedError);   
    let stackTrace = err.stack ? err.stack : "Stack trace not available";
    if (typeof err === 'string') {
        m.reply(`Terjadi error:\n\nKeterangan Error: ${errorMessage}`);
    } else {
        console.log(formattedError);
        alfixd.sendMessage("62895615063060@s.whatsapp.net", {
            text: `Alo ketua, ada error nih:\n\nKeterangan Error: ${errorMessage}\n\nStack Trace:\n${stackTrace}`,
            contextInfo: {
                forwardingScore: 9999999,
                isForwarded: true
            }
        });
    }
}
}
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(color(`Update ${__filename}`))
delete require.cache[file]
require(file)
})