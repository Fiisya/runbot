module.exports = {
    type: 'convert',
    command: ['shorten', 'shortlink', 'shorturl', 'shortenlink'],
    operate: async (context) => {
        const { alfixd, m, q, prefix, command, replyURL } = context;
 /*
 
        YOU CODE
 
 
 */
    }
};