Install di Pannel ⚙️:
1. add file dipanel
2. jika sudah masukan cmd npm start
3. keluar code pairing, masukan kode pairing ke nomor yg mau jadibot


Install di Termux 👨‍💻:
1. pkg install git
2. git clone https://github.com/Fiisya/Risa-WaBot
3. cd Risa-WaBot 
4. npm i
5. npm start
6. tinggal masukin aja pairing nya

///////////////////////////////////////////

Thanks 🙏
- Whiskeysocket/Baileys
- Tanaka Sensei
- Lepii (alfi)
- Dll
